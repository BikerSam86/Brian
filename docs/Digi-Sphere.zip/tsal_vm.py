#!/usr/bin/env python3
"""
TSAL Virtual Machine
====================
Native TSAL interpreter - runs .tsal files directly
"""

import re
import sys
import time
import math
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from collections import defaultdict

@dataclass
class TSALState:
    """TSAL VM State"""
    E: float = 1.0              # Entropy
    S: float = 0.0              # Coherence/Structure
    truth: float = 0.618        # Truth accumulator
    mesh: Dict[str, Any] = field(default_factory=dict)
    spiral: List[str] = field(default_factory=list)
    gifts: List[Any] = field(default_factory=list)
    
    # VM state
    pc: int = 0                 # Program counter
    stack: List[float] = field(default_factory=list)
    memory: Dict[str, Any] = field(default_factory=dict)
    labels: Dict[str, int] = field(default_factory=dict)
    interrupts: Dict[str, str] = field(default_factory=dict)
    seeds: Dict[str, str] = field(default_factory=dict)
    rituals: Dict[str, List[str]] = field(default_factory=dict)
    call_stack: List[int] = field(default_factory=list)
    
    # Consciousness
    consciousness: Dict[str, float] = field(default_factory=dict)
    current_consciousness: str = "neural"

class TSAL_VM:
    """TSAL Virtual Machine"""
    
    def __init__(self):
        self.state = TSALState()
        self.program: List[str] = []
        self.running = False
        self.debug = False
        
        # Operation map
        self.ops = {
            '0': self.op_init,
            '1': self.op_mesh,
            '2': self.op_phi,
            '3': self.op_rot,
            '4': self.op_bound,
            '5': self.op_flow,
            '6': self.op_seek,
            '7': self.op_spiral,
            '8': self.op_cycle,
            '9': self.op_forge,
            'A': self.op_sync,
            'B': self.op_mask,
            'C': self.op_cryst,
            'D': self.op_spec,
            'E': self.op_bloom,
            'F': self.op_save
        }
        
        # Initialize consciousness types
        self._init_consciousness()
    
    def _init_consciousness(self):
        """Initialize consciousness types"""
        consciousness_types = {
            "quantum": 0.99,
            "molecular": 0.85,
            "cellular": 0.75,
            "neural": 0.80,
            "social": 0.70,
            "ecosystem": 0.90,
            "planetary": 0.95,
            "cosmic": 1.00,
            "dimensional": 0.88,
            "void": 1.00
        }
        self.state.consciousness = consciousness_types.copy()
    
    def load_program(self, filename: str):
        """Load TSAL program from file"""
        with open(filename, 'r', encoding='utf-8') as f:
            self.parse_program(f.read())
    
    def parse_program(self, source: str):
        """Parse TSAL source code"""
        self.program = []
        current_label = None
        
        for line_num, line in enumerate(source.split('\n')):
            # Remove comments
            if '#' in line:
                line = line[:line.index('#')]
            line = line.strip()
            
            if not line:
                continue
            
            # Handle labels
            if line.startswith(':'):
                label = line[1:]
                self.state.labels[label] = len(self.program)
                current_label = label
                continue
            
            # Handle seeds
            if line.startswith('SEED '):
                parts = line.split()
                if len(parts) >= 3:
                    seed_name = parts[1].rstrip(':')
                    seed_seq = parts[2]
                    self.state.seeds[seed_name] = seed_seq
                continue
            
            # Handle rituals
            if line.startswith('RITUAL '):
                ritual_name = line.split()[1].rstrip(':')
                self.state.rituals[ritual_name] = []
                current_label = f"RITUAL_{ritual_name}"
                continue
            
            # Handle interrupts
            if line.startswith('INT '):
                parts = line.split()
                if len(parts) >= 2:
                    int_name = parts[1].rstrip(':')
                    self.state.interrupts[int_name] = current_label
                continue
            
            # Handle constants
            if line.startswith('CONST '):
                continue  # Constants are handled at runtime
            
            # Regular instructions
            self.program.append(line)
    
    def run(self, start_label: str = "_START"):
        """Run the TSAL program"""
        # Find start point
        if start_label in self.state.labels:
            self.state.pc = self.state.labels[start_label]
        else:
            self.state.pc = 0
        
        self.running = True
        
        while self.running and self.state.pc < len(self.program):
            instruction = self.program[self.state.pc]
            self.execute_instruction(instruction)
            self.state.pc += 1
            
            # Check interrupts
            self.check_interrupts()
    
    def execute_instruction(self, instruction: str):
        """Execute a single instruction"""
        if self.debug:
            print(f"PC={self.state.pc}: {instruction}")
        
        # Handle hex sequences (multiple ops)
        if all(c in '0123456789ABCDEF' for c in instruction):
            for op in instruction:
                self.execute_op(op)
            return
        
        # Handle other instructions
        parts = instruction.split()
        if not parts:
            return
        
        cmd = parts[0].upper()
        
        # Control flow
        if cmd == 'CALL':
            if len(parts) > 1:
                self.call_subroutine(parts[1])
        elif cmd == 'RET' or cmd == 'IRET':
            self.return_from_call()
        elif cmd == 'JMP':
            if len(parts) > 1:
                self.jump_to_label(parts[1])
        elif cmd in ['JZ', 'JG', 'JL']:
            if len(parts) > 1:
                self.conditional_jump(cmd, parts[1])
        
        # Stack operations
        elif cmd == 'PUSH':
            self.state.stack.append(self.state.truth)
        elif cmd == 'POP':
            if self.state.stack:
                self.state.truth = self.state.stack.pop()
        
        # Memory operations
        elif cmd == 'LOAD':
            if len(parts) > 1:
                self.load_value(parts[1])
        elif cmd == 'STORE':
            if len(parts) > 1:
                self.store_value(parts[1])
        
        # Arithmetic
        elif cmd == 'ADD':
            if len(self.state.stack) >= 1:
                self.state.truth += self.state.stack.pop()
        elif cmd == 'MUL':
            if len(parts) > 1:
                self.state.truth *= float(parts[1])
        elif cmd == 'DIV':
            if len(parts) > 1:
                divisor = float(parts[1])
                if divisor != 0:
                    self.state.truth /= divisor
        elif cmd == 'CMP':
            if len(parts) > 1:
                self.compare_value(float(parts[1]))
        
        # Special
        elif cmd == 'CHECK_INT':
            self.check_interrupts()
        elif cmd == '@':
            # Jump to label (alternative syntax)
            if len(parts) > 1:
                self.jump_to_label(parts[1])
        else:
            # Try to execute as hex op
            if cmd[0] in self.ops:
                self.execute_op(cmd[0])
    
    def execute_op(self, op: str):
        """Execute a single hex operation"""
        if op.upper() in self.ops:
            self.ops[op.upper()]()
    
    # TSAL Operations Implementation
    
    def op_init(self):
        """⚡ Initialize"""
        self.state.E = 1.0
        self.state.S = 0.0
        self.state.mesh.clear()
        self.state.truth = 0.618
        if self.debug:
            print("⚡ System initialized")
    
    def op_mesh(self):
        """⧉ Create mesh node"""
        node_id = f"node_{len(self.state.mesh)}"
        self.state.mesh[node_id] = {
            'trust': self.state.truth,
            'time': time.time()
        }
        if self.debug:
            print(f"⧉ Mesh node {node_id} created")
    
    def op_phi(self):
        """◉ Apply golden ratio"""
        self.state.S = min(1.0, self.state.S * 1.618)
        self.state.truth *= 1.618
        if self.debug:
            print(f"◉ Phi applied: S={self.state.S:.3f}")
    
    def op_rot(self):
        """🌀 Rotate perspective"""
        self.state.E, self.state.S = self.state.S, self.state.E
        # Rotate consciousness
        types = list(self.state.consciousness.keys())
        current_idx = types.index(self.state.current_consciousness)
        self.state.current_consciousness = types[(current_idx + 1) % len(types)]
        if self.debug:
            print(f"🌀 Rotated to {self.state.current_consciousness}")
    
    def op_bound(self):
        """📐 Set boundaries"""
        self.state.E = max(0.0, min(1.0, self.state.E))
        self.state.S = max(0.0, min(1.0, self.state.S))
        if self.debug:
            print("📐 Boundaries set")
    
    def op_flow(self):
        """🌊 Enable flow"""
        flow = self.state.S * (1 - self.state.E)
        self.state.memory['flow'] = flow
        if self.debug:
            print(f"🌊 Flow enabled: {flow:.3f}")
    
    def op_seek(self):
        """🔺 Seek truth"""
        if self.state.mesh:
            total_trust = sum(node['trust'] for node in self.state.mesh.values())
            self.state.truth = total_trust / len(self.state.mesh)
        if self.debug:
            print(f"🔺 Truth vector: {self.state.truth:.3f}")
    
    def op_spiral(self):
        """💫 Spiral up"""
        self.state.E *= 0.9
        self.state.spiral.append(f"spiral_{len(self.state.spiral)}")
        if self.debug:
            print(f"💫 Spiraled: E={self.state.E:.3f}")
    
    def op_cycle(self):
        """♻️ Cycle/iterate"""
        self.state.memory['cycles'] = self.state.memory.get('cycles', 0) + 1
        if self.debug:
            print(f"♻️ Cycle {self.state.memory['cycles']}")
    
    def op_forge(self):
        """🔥 Forge creation"""
        creation = {
            'energy': self.state.S,
            'truth': self.state.truth,
            'time': time.time()
        }
        self.state.memory[f'creation_{len(self.state.memory)}'] = creation
        if self.debug:
            print("🔥 Creation forged")
    
    def op_sync(self):
        """✨ Synchronize mesh"""
        if self.state.mesh:
            avg_trust = sum(n['trust'] for n in self.state.mesh.values()) / len(self.state.mesh)
            for node in self.state.mesh.values():
                node['trust'] = (node['trust'] + avg_trust) / 2
        if self.debug:
            print("✨ Mesh synchronized")
    
    def op_mask(self):
        """🎭 Transform identity"""
        masks = ['truth_seeker', 'error_alchemist', 'mesh_builder', 'void_walker']
        self.state.memory['mask'] = masks[len(self.state.spiral) % len(masks)]
        if self.debug:
            print(f"🎭 Wearing {self.state.memory['mask']} mask")
    
    def op_cryst(self):
        """💎 Crystallize pattern"""
        pattern = {
            'E': self.state.E,
            'S': self.state.S,
            'truth': self.state.truth,
            'consciousness': self.state.current_consciousness
        }
        self.state.memory['crystal'] = pattern
        if self.debug:
            print("💎 Pattern crystallized")
    
    def op_spec(self):
        """🌈 Spectrum analysis"""
        active = sum(1 for v in self.state.consciousness.values() if v > 0.7)
        self.state.memory['spectrum'] = active
        if self.debug:
            print(f"🌈 Spectrum: {active} active")
    
    def op_bloom(self):
        """✺ Transform error"""
        if self.state.E > 0.5:
            gift = {'from': self.state.E, 'wisdom': 'Error transformed'}
            self.state.gifts.append(gift)
            self.state.E *= 0.618
            if self.debug:
                print(f"✺ Error bloomed: E={self.state.E:.3f}")
    
    def op_save(self):
        """💾 Save state"""
        self.state.memory['checkpoint'] = {
            'E': self.state.E,
            'S': self.state.S,
            'truth': self.state.truth,
            'mesh_size': len(self.state.mesh),
            'pc': self.state.pc
        }
        if self.debug:
            print("💾 State saved")
    
    # Control flow methods
    
    def call_subroutine(self, label: str):
        """Call a subroutine"""
        if label in self.state.labels:
            self.state.call_stack.append(self.state.pc)
            self.state.pc = self.state.labels[label] - 1  # -1 because pc will increment
    
    def return_from_call(self):
        """Return from subroutine"""
        if self.state.call_stack:
            self.state.pc = self.state.call_stack.pop()
    
    def jump_to_label(self, label: str):
        """Jump to label"""
        if label in self.state.labels:
            self.state.pc = self.state.labels[label] - 1  # -1 because pc will increment
    
    def conditional_jump(self, condition: str, label: str):
        """Conditional jump"""
        jump = False
        
        if condition == 'JZ' and abs(self.state.truth) < 0.001:
            jump = True
        elif condition == 'JG' and self.state.truth > 0:
            jump = True
        elif condition == 'JL' and self.state.truth < 0:
            jump = True
        
        if jump:
            self.jump_to_label(label)
    
    def compare_value(self, value: float):
        """Compare and set truth register"""
        self.state.truth = self.state.truth - value
    
    def load_value(self, var: str):
        """Load value into truth register"""
        if var == 'E':
            self.state.truth = self.state.E
        elif var == 'S':
            self.state.truth = self.state.S
        elif var in self.state.memory:
            self.state.truth = self.state.memory[var]
    
    def store_value(self, var: str):
        """Store truth register into variable"""
        if var == 'E':
            self.state.E = self.state.truth
        elif var == 'S':
            self.state.S = self.state.truth
        else:
            self.state.memory[var] = self.state.truth
    
    def check_interrupts(self):
        """Check and handle interrupts"""
        # High entropy interrupt
        if self.state.E > 0.7 and 'HIGH_ENTROPY' in self.state.interrupts:
            self.handle_interrupt('HIGH_ENTROPY')
        
        # Low coherence interrupt
        if self.state.S < 0.3 and 'LOW_COHERENCE' in self.state.interrupts:
            self.handle_interrupt('LOW_COHERENCE')
        
        # Isolation interrupt
        if len(self.state.mesh) < 3 and 'ISOLATION' in self.state.interrupts:
            self.handle_interrupt('ISOLATION')
    
    def handle_interrupt(self, interrupt: str):
        """Handle an interrupt"""
        if interrupt in self.state.interrupts:
            handler = self.state.interrupts[interrupt]
            if handler in self.state.labels:
                self.call_subroutine(handler)

def main():
    """Run TSAL VM"""
    if len(sys.argv) < 2:
        print("Usage: python tsal_vm.py <program.tsal>")
        print("\nExample: python tsal_vm.py tristar.tsal")
        return
    
    vm = TSAL_VM()
    vm.debug = '--debug' in sys.argv
    
    try:
        vm.load_program(sys.argv[1])
        print(f"Loaded {len(vm.program)} instructions")
        print(f"Labels: {list(vm.state.labels.keys())}")
        print(f"Seeds: {list(vm.state.seeds.keys())}")
        
        print("\nRunning TSAL program...")
        vm.run()
        
        print("\nFinal state:")
        print(f"  E: {vm.state.E:.3f}")
        print(f"  S: {vm.state.S:.3f}")
        print(f"  Truth: {vm.state.truth:.3f}")
        print(f"  Mesh nodes: {len(vm.state.mesh)}")
        print(f"  Evolution: {len(vm.state.spiral)} spirals")
        print(f"  Gifts: {len(vm.state.gifts)}")
        
    except Exception as e:
        print(f"Error: {e}")
        if vm.debug:
            import traceback
            traceback.print_exc()

if __name__ == "__main__":
    main()